# lsmod

> Shows the status of Linux kernel modules.
> See also `modprobe`, which loads kernel modules.

- List all currently loaded kernel modules:

`lsmod`
