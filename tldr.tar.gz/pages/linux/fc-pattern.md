# fc-pattern

> Shows information about a font matching a pattern.
> More information: <https://manned.org/fc-pattern>.

- Display default information about a font:

`fc-pattern --default '{{DejaVu Serif}}'`

- Display config information about a font:

`fc-pattern --config '{{DejaVu Serif}}'`
