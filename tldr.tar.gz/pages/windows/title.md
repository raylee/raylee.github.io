# title

> Set the title of the command prompt window.
> More information: <https://docs.microsoft.com/windows-server/administration/windows-commands/title>.

- Set the title of the current command prompt window:

`title {{new_title}}`
